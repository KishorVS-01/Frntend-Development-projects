function appendValue(value) {
    document.getElementById("display").value += value;
}

function clearDisplay() {
    document.getElementById("display").value = "";
}


function calculate() {
    try {
         let expression = document.getElementById("display").value;
        expression = expression.replace(/%/g, "/100");
        let result = eval(expression);
        document.getElementById("display").value = result;
    } catch {
        document.getElementById("display").value = "Error";
    }
}

function deleteNumber() {
    let display = document.getElementById("display");
    display.value = display.value.slice(0,-1);
    }