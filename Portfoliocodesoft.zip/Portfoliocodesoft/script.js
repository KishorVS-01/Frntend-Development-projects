const contactButton = document.querySelector('#contact');
contactButton.addEventListener('click', function() {
    const connectSection = document.querySelector('.Connect');
    
    if (connectSection) {
        connectSection.scrollIntoView({ behavior: 'smooth' });
    }
});

